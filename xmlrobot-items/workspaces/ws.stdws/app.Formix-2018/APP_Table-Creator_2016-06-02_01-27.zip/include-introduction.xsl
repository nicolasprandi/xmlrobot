<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright © 2015 Nicolas Prandstaetter. 
This file is part of an Ava-Application.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This file is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the Ava-Application.  If not, see &lt;http://www.gnu.org/licenses/&gt;. -->

<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:template match="action" mode="header">
  <ti>
      <xsl:attribute name="x">
        <xsl:text> </xsl:text>
      </xsl:attribute>         
        
  </ti>
</xsl:template>

<xsl:template name="action2">
            <xsl:attribute name="explain">
              <xsl:value-of select="@label" />
            </xsl:attribute>  
            <xsl:attribute name="job">
              <xsl:value-of select="@hook_job" />
            </xsl:attribute>  
 
            <xsl:if test="string-length(@call_flag)>0">
              <xsl:attribute name="flag">
                <xsl:value-of select="@call_flag" />
              </xsl:attribute>              
            </xsl:if>         

</xsl:template>

<xsl:template name="inner_hook">
<xsl:param name="page"/>
            <prop>           
              <xsl:attribute name="id">
                <xsl:text>greetings_from_page</xsl:text>
              </xsl:attribute>          
              <xsl:value-of select="$page" />
            </prop>   
            <prop>           
              <xsl:attribute name="id">
                <xsl:text>greetings_from_action</xsl:text>
              </xsl:attribute>          
              <xsl:value-of select="@id" />
            </prop>             
  <xsl:choose>
    <xsl:when test="$page='view'">
            <prop>
        <xsl:attribute name="page">
          <xsl:value-of select="$page" />
        </xsl:attribute>              
              <xsl:attribute name="id">
                <xsl:value-of select="//conf/s2/@key" /> 
              </xsl:attribute>          
              <xsl:value-of select="//conf/s2/@loop_i_row" />
            </prop>    
            
    </xsl:when>
    <xsl:when test="$page='details'">

      <prop>
        <xsl:attribute name="page">
          <xsl:value-of select="$page" />
        </xsl:attribute>      
        <xsl:attribute name="id">
          <xsl:value-of select="//conf/s1/@singular_id" /><xsl:text>_key</xsl:text>
        </xsl:attribute>
        <xsl:text>(prop,</xsl:text>
        <xsl:value-of select="//conf/s1/@singular_id" /><xsl:text>_key</xsl:text>
        <xsl:text>)</xsl:text>
      </prop>       
    
    </xsl:when>    
  </xsl:choose>
  
   
</xsl:template>
  
<xsl:template match="action" mode="ti_call">
<xsl:param name="page"/>

        <ti isFromAction="1">
          <xsl:attribute name="type">
            <xsl:value-of select="//conf/s2/@ti_call" />
          </xsl:attribute>
          <xsl:attribute name="page">
            <xsl:value-of select="$page" />
          </xsl:attribute>          
        
          <xsl:call-template name="action2"/>  
          
          <xsl:call-template name="inner_hook">          
            <xsl:with-param name="page" select="$page"/>
          </xsl:call-template>
          
            <xsl:call-template name="introduction"  />
                                     
        </ti>
            
</xsl:template>


<xsl:template name="introduction">

    <!-- ins include - begin -->
    <file>
      <xsl:attribute name="id">
        <xsl:value-of select="//conf/s1/@plural_id" />
      </xsl:attribute>
      <xsl:text>(file,</xsl:text>
      <xsl:value-of select="//conf/s1/@plural_id" />
      <xsl:text>)</xsl:text>
    </file>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="//conf/s1/@plural_id" /><xsl:text>_offset</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="//conf/s1/@plural_id" /><xsl:text>_offset</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>    
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="//conf/s1/@plural_id" /><xsl:text>_offset_label</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="//conf/s1/@plural_id" /><xsl:text>_offset_label</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="//conf/s1/@plural_id" /><xsl:text>_offset_new_key</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="//conf/s1/@plural_id" /><xsl:text>_offset_new_key</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="//conf/s1/@plural_id" />
        <xsl:text>_sort_attribute</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="//conf/s1/@plural_id" /><xsl:text>_sort_attribute</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="//conf/s1/@plural_id" />
        <xsl:text>_sort_number</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="//conf/s1/@plural_id" /><xsl:text>_sort_number</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="//conf/s1/@plural_id" />
        <xsl:text>_where</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="//conf/s1/@plural_id" /><xsl:text>_where</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="//conf/s2/@return_job" />
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="//conf/s2/@return_job" />
      <xsl:text>)</xsl:text>
    </prop> 
    <!--
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="//conf/s1/@singular_id" />
        <xsl:text>_key23</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="//conf/s1/@singular_id" /><xsl:text>_key</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>      -->  
    
    <xsl:apply-templates select="//parents/parent" mode="introduction"/>
    
    <!-- ins include - end -->

</xsl:template>

<xsl:template match="parent" mode="introduction">

    <file>
      <xsl:attribute name="id">
        <xsl:value-of select="@parent_plural_id" />
      </xsl:attribute>
      <xsl:text>(file,</xsl:text>
      <xsl:value-of select="@parent_plural_id" />
      <xsl:text>)</xsl:text>
    </file>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="@parent_plural_id" /><xsl:text>_offset</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@parent_plural_id" /><xsl:text>_offset</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>    
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="@parent_plural_id" /><xsl:text>_offset_label</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@parent_plural_id" /><xsl:text>_offset_label</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="@parent_plural_id" /><xsl:text>_offset_new_key</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@parent_plural_id" /><xsl:text>_offset_new_key</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="@parent_plural_id" />
        <xsl:text>_sort_attribute</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@parent_plural_id" /><xsl:text>_sort_attribute</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="@parent_plural_id" />
        <xsl:text>_sort_number</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@parent_plural_id" /><xsl:text>_sort_number</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="@parent_plural_id" />
        <xsl:text>_where</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@parent_plural_id" /><xsl:text>_where</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="@parent_plural_id" />
        <xsl:text>_return_job</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@parent_plural_id" /><xsl:text>_return_job</xsl:text>
      <xsl:text>)</xsl:text>
    </prop>
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="@parent_singular_id" />
        <xsl:text>_key</xsl:text>
      </xsl:attribute>
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@parent_singular_id" /><xsl:text>_key</xsl:text>
      <xsl:text>)</xsl:text>
    </prop> 

</xsl:template>

</xsl:stylesheet>
