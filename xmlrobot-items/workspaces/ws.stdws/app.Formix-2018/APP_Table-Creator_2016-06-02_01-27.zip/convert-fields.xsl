<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright © 2015 Nicolas Prandstaetter. 
This file is part of an Ava-Application.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This file is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the Ava-Application.  If not, see &lt;http://www.gnu.org/licenses/&gt;. -->


<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  
<xsl:param name="singular_id"/>   
<xsl:param name="name_separator"/> 

<xsl:output method="xml"/>

<xsl:template match="/">
   <xsl:apply-templates/>
</xsl:template>

<xsl:template match="fields">
  <fields>
    <xsl:copy-of select="@*"/>
    <xsl:attribute name="name_expression">
      <!-- <xsl:apply-templates select="field[@name_flag=1]" mode="expression"/> -->
      <xsl:for-each select="field[@name_flag=1]" >
        <xsl:sort select="@position" data-type="number"/>
        <xsl:choose>
          <xsl:when test="@type='dir'">
            <xsl:text>(dir,</xsl:text>
          </xsl:when>
          <xsl:when test="@type='file'">
            <xsl:text>(file,</xsl:text>
          </xsl:when>      
          <xsl:otherwise>
            <xsl:text>(prop,</xsl:text>
          </xsl:otherwise>
        </xsl:choose>            
        <xsl:value-of select="$singular_id" />
        <xsl:text>_</xsl:text>
        <xsl:value-of select="@id" />
        <xsl:text>)</xsl:text>    
        <xsl:if test="not(position()=last())">
          <xsl:value-of select="$name_separator"/>
        </xsl:if>  
      </xsl:for-each>
    </xsl:attribute>
    <xsl:attribute name="name_expression_loop">
      <!-- <xsl:apply-templates select="field[@name_flag=1]" mode="expression"/> -->
      <xsl:for-each select="field[@name_flag=1]" >
        <xsl:sort select="@position" data-type="number"/>
        <xsl:text>(loop,i,@</xsl:text>
        <xsl:value-of select="@id" />
        <xsl:text>)</xsl:text>    
        <xsl:if test="not(position()=last())">
          <xsl:value-of select="$name_separator"/>
        </xsl:if>  
      </xsl:for-each>
    </xsl:attribute>    
    <xsl:apply-templates select="field" mode="data"/>
  </fields>
</xsl:template>

<xsl:template match="field" mode="data">
  <field>
    <xsl:copy-of select="@*"/>
    <xsl:attribute name="vartype">
      <xsl:choose>
        <xsl:when test="@type='dir'">
          <xsl:text>dir</xsl:text>
        </xsl:when>
        <xsl:when test="@type='file'">
          <xsl:text>file</xsl:text>
        </xsl:when>      
        <xsl:otherwise>
          <xsl:text>prop</xsl:text>
        </xsl:otherwise>
      </xsl:choose> 
     </xsl:attribute>   
    <xsl:attribute name="var">
      <xsl:text>(</xsl:text>
      <xsl:choose>
        <xsl:when test="@type='dir'">
          <xsl:text>dir</xsl:text>
        </xsl:when>
        <xsl:when test="@type='file'">
          <xsl:text>file</xsl:text>
        </xsl:when>      
        <xsl:otherwise>
          <xsl:text>prop</xsl:text>
        </xsl:otherwise>
      </xsl:choose>     
      <xsl:text>,</xsl:text> 
      <xsl:value-of select="$singular_id" />
      <xsl:text>_</xsl:text>
      <xsl:value-of select="@id" />
      <xsl:text>)</xsl:text> 
     </xsl:attribute>           
  </field>
</xsl:template>
<!-- 
<xsl:template match="field" mode="expression">
  <xsl:text>(prop,</xsl:text>
  <xsl:value-of select="$singular_id" />
  <xsl:text>_</xsl:text>
  <xsl:value-of select="@id" />
  <xsl:text>) </xsl:text>
</xsl:template>
-->

</xsl:stylesheet>

  
