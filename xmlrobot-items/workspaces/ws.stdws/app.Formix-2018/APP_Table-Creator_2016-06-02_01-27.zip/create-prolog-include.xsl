<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright © 2015 Nicolas Prandstaetter. 
This file is part of an Ava-Application.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This file is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the Ava-Application.  If not, see &lt;http://www.gnu.org/licenses/&gt;. -->


<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:output method="xml" indent="yes"/>

<xsl:template match="/">
   <xsl:apply-templates/>
</xsl:template>

<xsl:template match="conf">
  <prolog>
  
<include>
  <xsl:attribute name="file">
    <xsl:choose>
      <xsl:when test="s2/@usage='app'">
        <xsl:text>(dir,app)</xsl:text>
      </xsl:when>
      <xsl:when test="s2/@usage='service'">
        <xsl:text>(dir,services)</xsl:text>
      </xsl:when>  
    </xsl:choose>
    <xsl:value-of select="s2/@filename_prolog" />
  </xsl:attribute>
</include>

  </prolog>
</xsl:template>

</xsl:stylesheet>

  
