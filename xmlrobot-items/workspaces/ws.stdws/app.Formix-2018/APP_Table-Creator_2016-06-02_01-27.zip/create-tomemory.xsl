<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright © 2015 Nicolas Prandstaetter. 
This file is part of an Ava-Application.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This file is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the Ava-Application.  If not, see &lt;http://www.gnu.org/licenses/&gt;. -->


<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:output method="xml" indent="yes"/>
<xsl:include href="include-hooks2.xsl" />

<xsl:template match="/">
   <xsl:apply-templates/>
</xsl:template>

<xsl:template match="conf">

<!-- <job id="City to_memory" role="hidden" >  -->
<job role="hidden">
  <xsl:attribute name="id"><xsl:value-of select="s2/@job_city_tomemory" /></xsl:attribute> 
  
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">begin</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>
             
  <need><xsl:value-of select="s2/@prop_key" /></need>
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">0</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>
  <!-- 
  <xsl:text></xsl:text>
  <xsl:value-of select="s2/@" />
  <xsl:text></xsl:text>
  <xsl:value-of select="s2/@" />
  <xsl:text></xsl:text>
  <xsl:value-of select="s2/@" />
  <xsl:text></xsl:text>
  <xsl:value-of select="s2/@" />
  -->
    
  <!-- <prop id="city_dt_upd">(f,xpathx,,(file,cities),(prop,cities_offset)city[@row='(prop,rec_id)'],@dt_upd)</prop>  
       <prop id="city_dt_add">(f,xpathx,,(file,cities),(prop,cities_offset)city[@row='(prop,rec_id)'],@dt_add)</prop> -->
  <spirit act="open">
      <xsl:attribute name="id">
        <xsl:value-of select="s2/@spirit" />
      </xsl:attribute>
      <xsl:attribute name="xml">
        <xsl:value-of select="s2/@file_cities" />
      </xsl:attribute>      
  </spirit>
      
  <xsl:if test="string-length(s1/@dt_upd)>0">
  
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">0</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>  

    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="s2/@city_dt_upd" />
      </xsl:attribute>
      <xsl:text>(f,spirit,</xsl:text>
      <xsl:value-of select="s2/@spirit" />
      <xsl:text>,xpathx,,</xsl:text>
      <xsl:value-of select="s2/@prop_cities_offset" />
      <xsl:value-of select="s1/@singular_id" />
      <xsl:text>[@</xsl:text>
      <xsl:value-of select="s1/@id_attribute_name" />
      <xsl:text>='</xsl:text> 
      <xsl:value-of select="s2/@prop_key" /> 
      <xsl:text>'],@dt_upd)</xsl:text>          
    </prop>    
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">0</xsl:with-param>
          <xsl:with-param name="station">1</xsl:with-param>
        </xsl:call-template>
  </xsl:if>
  
  <xsl:if test="string-length(s1/@dt_add)>0">
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">1</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>  
    
    <prop>
      <xsl:attribute name="id">
        <xsl:value-of select="s2/@city_dt_add" />
      </xsl:attribute>
      <xsl:text>(f,spirit,</xsl:text>
      <xsl:value-of select="s2/@spirit" />
      <xsl:text>,xpathx,,</xsl:text>
      <xsl:value-of select="s2/@prop_cities_offset" />
      <xsl:value-of select="s1/@singular_id" />
      <xsl:text>[@</xsl:text>
      <xsl:value-of select="s1/@id_attribute_name" />
      <xsl:text>='</xsl:text> 
      <xsl:value-of select="s2/@prop_key" /> 
      <xsl:text>'],@dt_add)</xsl:text>          
    </prop>    
    
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">1</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>
  </xsl:if>  
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">2</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>  
  <xsl:apply-templates select="fields/field" mode="tomemory"/>
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">2</xsl:with-param>
          <xsl:with-param name="station">1</xsl:with-param>
        </xsl:call-template> 
  <spirit act="close">
      <xsl:attribute name="id">
        <xsl:value-of select="s2/@spirit" />
      </xsl:attribute>   
  </spirit>  
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">end</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>          
</job>
</xsl:template>

<!-- ******************************************* -->
<xsl:template match="field" mode="tomemory">
  <!-- <prop id="city_name">(f,xpathx,,(file,cities),(prop,cities_offset)city[@row='(prop,rec_id)'],@name)</prop>
  -->
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">3</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>  
      <xsl:choose>
        <xsl:when test="@vartype='dir'">
        
          <dir flag="cool">
            <xsl:attribute name="id">
              <xsl:value-of select="//s1/@singular_id" />
              <xsl:text>_</xsl:text>
              <xsl:value-of select="@id" />    
            </xsl:attribute>
            <xsl:call-template name="x2" />       
          </dir>
          <!-- 
          <echo label="pos 1: gelesen" type="dir">
            <xsl:attribute name="id">
              <xsl:value-of select="//s1/@singular_id" />
              <xsl:text>_</xsl:text>
              <xsl:value-of select="@id" />    
            </xsl:attribute>       
          </echo>
          -->
          <export type="dir">
            <xsl:attribute name="id">
              <xsl:value-of select="//s1/@singular_id" />
              <xsl:text>_</xsl:text>
              <xsl:value-of select="@id" />    
            </xsl:attribute>          
          </export>
          <!--
          <echo label="pos 2: exported" type="dir">
            <xsl:attribute name="id">
              <xsl:value-of select="//s1/@singular_id" />
              <xsl:text>_</xsl:text>
              <xsl:value-of select="@id" />    
            </xsl:attribute>       
          </echo>
          -->                    
          <translate type="dir">
            <xsl:attribute name="id">
              <xsl:value-of select="//s1/@singular_id" />
              <xsl:text>_</xsl:text>
              <xsl:value-of select="@id" />    
            </xsl:attribute>          
          </translate>
          <!--
          <echo label="pos 3: translated" type="dir">
            <xsl:attribute name="id">
              <xsl:value-of select="//s1/@singular_id" />
              <xsl:text>_</xsl:text>
              <xsl:value-of select="@id" />    
            </xsl:attribute>       
          </echo>          
          -->
        </xsl:when>
        <xsl:when test="@vartype='file'">
          <file>
            <xsl:attribute name="id">
              <xsl:value-of select="//s1/@singular_id" />
              <xsl:text>_</xsl:text>
              <xsl:value-of select="@id" />    
            </xsl:attribute>
            <xsl:call-template name="x2" />       
          </file>

          <export type="file">
            <xsl:attribute name="id">
              <xsl:value-of select="//s1/@singular_id" />
              <xsl:text>_</xsl:text>
              <xsl:value-of select="@id" />    
            </xsl:attribute>          
          </export>
          
          <translate type="file">
            <xsl:attribute name="id">
              <xsl:value-of select="//s1/@singular_id" />
              <xsl:text>_</xsl:text>
              <xsl:value-of select="@id" />    
            </xsl:attribute>          
          </translate>
          
        </xsl:when>      
        <xsl:otherwise>
          <prop>
            <xsl:call-template name="x1"/>
          </prop>
        </xsl:otherwise>
      </xsl:choose>  
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">tomemory</xsl:with-param>
          <xsl:with-param name="hook">3</xsl:with-param>
          <xsl:with-param name="station">1</xsl:with-param>
        </xsl:call-template>        
</xsl:template>

<xsl:template name="x1">
    <xsl:attribute name="id">
      <xsl:value-of select="//s1/@singular_id" />
      <xsl:text>_</xsl:text>
      <xsl:value-of select="@id" />    
    </xsl:attribute>
    <xsl:call-template name="x2" />

</xsl:template>

<xsl:template name="x2">
    <!-- 
    <xsl:text>(f,xpathx,,</xsl:text>
    <xsl:value-of select="//s2/@file_cities" />
    <xsl:text>,</xsl:text>
    <xsl:value-of select="//s2/@prop_cities_offset" />
    <xsl:value-of select="//s1/@singular_id" />
    <xsl:text>[@</xsl:text>
    <xsl:value-of select="//s1/@id_attribute_name" />   
    <xsl:text>='</xsl:text>
    <xsl:value-of select="//s2/@prop_key" />
    <xsl:text>'],@</xsl:text>
    <xsl:value-of select="@id" />
    <xsl:text>)</xsl:text> 
    -->
    
    <xsl:text>(f,spirit,</xsl:text>
    <xsl:value-of select="//s2/@spirit" />
    <xsl:text>,xpathx,,</xsl:text>
    <xsl:value-of select="//s2/@prop_cities_offset" />
    <xsl:value-of select="//s1/@singular_id" />
    <xsl:text>[@</xsl:text>
    <xsl:value-of select="//s1/@id_attribute_name" />
    <xsl:text>='</xsl:text> 
    <xsl:value-of select="//s2/@prop_key" /> 
    <xsl:text>'],@</xsl:text>
    <xsl:value-of select="@id" />
    <xsl:text>)</xsl:text>             

</xsl:template>


</xsl:stylesheet>

  
