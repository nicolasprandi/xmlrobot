<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright © 2015 Nicolas Prandstaetter. 
This file is part of an Ava-Application.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This file is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the Ava-Application.  If not, see &lt;http://www.gnu.org/licenses/&gt;. -->


<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:output method="xml" indent="yes"/>
<xsl:include href="include-introduction.xsl" />
<xsl:include href="include-hooks2.xsl" />
<xsl:template match="/">
   <xsl:apply-templates/>
</xsl:template>

<xsl:template match="conf">
<xsl:variable name="test">1</xsl:variable>

<!-- <job id="View Cities" level="app" >  -->
<job>
  <xsl:attribute name="id"><xsl:value-of select="s2/@job_city_view" /></xsl:attribute>
  <xsl:attribute name="level">
    <xsl:value-of select="s1/@job_level" />
  </xsl:attribute>  
  <xsl:attribute name="role">
    <xsl:value-of select="s1/@job_role_view" />
  </xsl:attribute>    
  <xsl:attribute name="tip">
    <xsl:text>Lists all </xsl:text>
    <xsl:value-of select="s1/@plural_label" />
  </xsl:attribute>    
  <xsl:call-template name="hook2">
    <xsl:with-param name="page">view</xsl:with-param>
    <xsl:with-param name="hook">begin</xsl:with-param>
    <xsl:with-param name="station">0</xsl:with-param>
  </xsl:call-template>
  
  <!--  <ti type="call" explain="Add new City(prop,cities_offset_label)" job="City Add" /> -->
  

  <xsl:if test="s1/@view_add=1 and (s1/@view_add_location='top')">
    <xsl:call-template name="add_button"/>
  </xsl:if>


  
  <prop id="nothing">1</prop>
  
  <xsl:call-template name="hook2">
    <xsl:with-param name="page">view</xsl:with-param>
    <xsl:with-param name="hook">0</xsl:with-param>
    <xsl:with-param name="station">0</xsl:with-param>
  </xsl:call-template>
    
  <!-- <loop id="i" xml="(file,cities)" xpath="(prop,cities_offset)city" sort="id" number="id">  -->
  <loop id="i">
    <xsl:attribute name="xml">
      <xsl:value-of select="s2/@file_cities" />
    </xsl:attribute>  
    <xsl:attribute name="xpath">
      <xsl:value-of select="s2/@prop_cities_offset" />
      <xsl:value-of select="s1/@singular_id" />
      <xsl:value-of select="s2/@prop_cities_where" />
    </xsl:attribute>

    <xsl:attribute name="sort">
      <xsl:value-of select="s2/@prop_cities_sort_attribute" />
    </xsl:attribute>
  
    <xsl:attribute name="number">
      <xsl:value-of select="s2/@prop_cities_sort_number" />
    </xsl:attribute>  
    
    <xsl:attribute name="ignore_case">
      <xsl:value-of select="s2/@prop_cities_sort_ignore_case" />
    </xsl:attribute>
    
    <xsl:attribute name="desc">
      <xsl:value-of select="s2/@prop_cities_sort_desc" />
    </xsl:attribute>          
    
    <when test="(prop,nothing)">
      <!-- <ti label="List of Cities(prop,cities_offset_label)" size="2" padding_top="6px">  -->
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">view</xsl:with-param>
          <xsl:with-param name="hook">1</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>
        <xsl:if test="s1/@view_padding_top='1'">
          <ti><ti/></ti>       
        </xsl:if>   
        
        <when>
          <xsl:attribute name="test">
            <xsl:text>(f,gt,(f,len,</xsl:text>
            <xsl:value-of select="s2/@prop_cities_offset_label" />
            <xsl:text>),0)</xsl:text>
          </xsl:attribute>
          <ti>(f,html,bold,open)<xsl:value-of select="s2/@prop_cities_offset_label" /><xsl:text>: </xsl:text>(f,html,bold,close)</ti>
        </when>
        
        
        <xsl:if test="count(fields/field[@view_flag=1])">
        <ti type="rec" label=" ">
          <xsl:call-template name="insert_view_trailer"/>
          <!-- 
          <xsl:attribute name="label_width">
            <xsl:value-of select="s1/@id_width_px" /><xsl:text>px</xsl:text>
          </xsl:attribute>
          -->
          
          <!-- loop <ti x="(f,html,bold,open)Name(f,html,bold,close)" width="100px" />  -->
          <xsl:apply-templates select="fields/field" mode="header">    
            <xsl:sort select="@position"/>
          </xsl:apply-templates> 
            
   

            
          <xsl:if test="s1/@view_details=1">
            <ti x=" ">
        
            </ti>
          </xsl:if>
          
          <xsl:if test="s1/@view_edit=1">
            <ti x=" ">
         
            </ti> 
           </xsl:if> 
           
           <xsl:if test="s1/@view_delete=1">        
            <ti x=" ">
         
            </ti> 
           </xsl:if>    
          
          <xsl:apply-templates select="//conf/actions/action[@view=1]" mode="header">    
            <xsl:sort select="@sort"/>
          </xsl:apply-templates>     

          
        </ti>  
        
        </xsl:if>
        
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">view</xsl:with-param>
          <xsl:with-param name="hook">1</xsl:with-param>
          <xsl:with-param name="station">1</xsl:with-param>
        </xsl:call-template> 
      <prop id="nothing">0</prop> 
    </when>
    
    <!-- <ti type="rec" label="((loop,i,@row))"  label_width="20px"> -->
    <xsl:call-template name="hook2">
      <xsl:with-param name="page">view</xsl:with-param>
      <xsl:with-param name="hook">2</xsl:with-param>
      <xsl:with-param name="station">0</xsl:with-param>
    </xsl:call-template> 
    <ti type="rec">
      <xsl:if test="s2/@see_keys=1">
        <xsl:attribute name="key">
          <xsl:text>#(loop,i,@</xsl:text><xsl:value-of select="s1/@id_attribute_name" /><xsl:text>)</xsl:text>
        </xsl:attribute>    
      </xsl:if>
      <xsl:attribute name="label"> 
        <xsl:choose>
          <xsl:when test="string-length(s1/@cut_view)>0">
            <xsl:text>(f,html,bold,open)</xsl:text>
            <xsl:text>(f,cut,nice,</xsl:text>
            <xsl:value-of select="//fields/@name_expression_loop" />
            <xsl:text>,</xsl:text>
            <xsl:value-of select="s1/@cut_view" />
            <xsl:text>)</xsl:text>
            <xsl:text>(f,html,bold,close)</xsl:text>          
          </xsl:when>
          <xsl:otherwise>
            <xsl:text>(f,html,bold,open)</xsl:text>
            <xsl:value-of select="//fields/@name_expression_loop" />
            <xsl:text>(f,html,bold,close)</xsl:text>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:attribute>    
      <!--     
      <xsl:attribute name="label_width">
        <xsl:value-of select="s1/@id_width_px" /><xsl:text>px</xsl:text>
      </xsl:attribute>
      -->
      <xsl:call-template name="insert_view_trailer"/>
      <xsl:apply-templates select="fields/field" mode="data">    
        <xsl:sort select="@position"/>
      </xsl:apply-templates>  
      
      <!-- 
      <ti type="call" explain="Details" width="50px" job="City Details" >
        <prop id="rec_id">(loop,i,@row)</prop>
      </ti>
      -->
      <xsl:if test="s1/@view_details=1">   
      <ti>
        <xsl:attribute name="type">
          <xsl:value-of select="s2/@ti_call" />
        </xsl:attribute>       
        
        <xsl:attribute name="explain">
          <xsl:value-of select="s1/@label_details" />
        </xsl:attribute>   
        <xsl:attribute name="job">
          <xsl:value-of select="s2/@job_city_details" />
        </xsl:attribute>            
        <prop>
          <xsl:attribute name="id">
            <xsl:value-of select="s2/@key" /> 
          </xsl:attribute>          
          <xsl:value-of select="s2/@loop_i_row" />
        </prop>
        <xsl:call-template name="introduction"/>
      </ti>
      </xsl:if>      
      
      <!--
      <ti type="call" explain="Edit" width="50px" job="City Edit" >
        <prop id="rec_id">(loop,i,@row)</prop>
      </ti>  
      --> 
      <xsl:if test="s1/@view_edit=1">  
      <ti>
        <xsl:attribute name="type">
          <xsl:value-of select="s2/@ti_call" />
        </xsl:attribute>          
      
        <xsl:attribute name="explain">
          <xsl:value-of select="s1/@label_edit" />
        </xsl:attribute>   
        <xsl:attribute name="job">
          <xsl:value-of select="s2/@job_city_edit" />
        </xsl:attribute>            
        <prop>
          <xsl:attribute name="id">
            <xsl:value-of select="s2/@key" /> 
          </xsl:attribute>          
          <xsl:value-of select="s2/@loop_i_row" />
        </prop>
        <xsl:call-template name="introduction"/>
      </ti>
      </xsl:if>        
                  
      <!--
      <ti type="call" explain="Delete" width="50px" job="City Delete" >
        <prop id="rec_id">(loop,i,@row)</prop>
      </ti> 
      --> 
      <xsl:if test="s1/@view_delete=1">
      <ti>
        <xsl:attribute name="type">
          <xsl:value-of select="s2/@ti_call" />
        </xsl:attribute>          
        
        <xsl:attribute name="explain">
          <xsl:value-of select="s1/@label_delete" />
        </xsl:attribute>   
        <xsl:attribute name="job">
          <xsl:value-of select="s2/@job_city_delete" />
        </xsl:attribute>            
        <prop>
          <xsl:attribute name="id">
            <xsl:value-of select="s2/@key" /> 
          </xsl:attribute>          
          <xsl:value-of select="s2/@loop_i_row" />
        </prop>
        <xsl:call-template name="introduction"/>
      </ti>
      </xsl:if>        
     
      <xsl:apply-templates select="//conf/actions/action[@view='1']" mode="ti_call">
      <xsl:with-param name="page"><xsl:text>view</xsl:text></xsl:with-param>
        <xsl:sort select="@sort"/>                    
      </xsl:apply-templates>           
    </ti>  
    
    <xsl:call-template name="hook2">
      <xsl:with-param name="page">view</xsl:with-param>
      <xsl:with-param name="hook">2</xsl:with-param>
      <xsl:with-param name="station">1</xsl:with-param>
    </xsl:call-template> 
               
  </loop>

  <xsl:call-template name="hook2">
    <xsl:with-param name="page">view</xsl:with-param>
    <xsl:with-param name="hook">3</xsl:with-param>
    <xsl:with-param name="station">0</xsl:with-param>
  </xsl:call-template>
      
  <when test="(prop,nothing)">
    <ti><xsl:text>No </xsl:text><xsl:value-of select="s1/@plural_label" /><xsl:text> found</xsl:text></ti>
  <xsl:call-template name="hook2">
    <xsl:with-param name="page">view</xsl:with-param>
    <xsl:with-param name="hook">4</xsl:with-param>
    <xsl:with-param name="station">0</xsl:with-param>
  </xsl:call-template>
  </when>

  <xsl:call-template name="hook2">
    <xsl:with-param name="page">view</xsl:with-param>
    <xsl:with-param name="hook">5</xsl:with-param>
    <xsl:with-param name="station">0</xsl:with-param>
  </xsl:call-template>
    
  <xsl:if test="s1/@view_add=1 and s1/@view_add_location='bottom'">
    <xsl:call-template name="add_button"/>
  </xsl:if>  

  <xsl:call-template name="hook2">
    <xsl:with-param name="page">view</xsl:with-param>
    <xsl:with-param name="hook">6</xsl:with-param>
    <xsl:with-param name="station">0</xsl:with-param>
  </xsl:call-template>
      
  <!--   <ti label="Data" padding_top="6px" size="2">
    <ti label="File:" type="file">(file,cities)</ti>
    <ti label="Xml-Offset:" test="(f,gt,(f,len,(prop,cities_offset)),0)">(prop,cities_offset)</ti>
  </ti>  -->

  <when test="(f,has_flag,debug trace all,(f,loglevel))">
    <!--
    <when test="(f,role,dev)"> 
    <xsl:if test="not(s1/@no_break_file=1)">
      <ti_break/>
    </xsl:if> 
    -->   
         
      <xsl:call-template name="hook2">
        <xsl:with-param name="page">view</xsl:with-param>
        <xsl:with-param name="hook">8</xsl:with-param>
        <xsl:with-param name="station">0</xsl:with-param>
      </xsl:call-template>
        <ti_hr/>
        <ti label="Debug Information">
        <ti label="File:" type="file"><xsl:value-of select="s2/@file_cities" /></ti>

        <ti label="Xml-Offset:">
          <xsl:attribute name="test">
            <xsl:text>(f,gt,(f,len,</xsl:text>
            <xsl:value-of select="s2/@prop_cities_offset" />
            <xsl:text>),0)</xsl:text>
          </xsl:attribute>     
          <xsl:value-of select="s2/@prop_cities_offset" />    
        </ti>
        </ti>



  </when>
  
  <xsl:call-template name="hook2">
    <xsl:with-param name="page">view</xsl:with-param>
    <xsl:with-param name="hook">end</xsl:with-param>
    <xsl:with-param name="station">0</xsl:with-param>
  </xsl:call-template>     

  
</job>
</xsl:template>

<!-- ******************************************* -->
<xsl:template match="field" mode="data">
  <!-- <ti x="(f,when,(f,exxists,(loop,i,@name)),(f,substring,(loop,i,@name),0,30),?)" width="100px" />  
  <ti x="(f,when,(f,exxists,(loop,i,@name)),(loop,i,@name),?)" width="100px" />
  -->
  <xsl:if test="@view_flag=1">
     <ti>
        <xsl:attribute name="type">  <!-- 14.4 -->
          <xsl:choose>
            <xsl:when test="@type='bool'">
              <xsl:text>text</xsl:text>
            </xsl:when>
            <xsl:when test="@type='sel'">
              <xsl:text>text</xsl:text>
            </xsl:when>            
            <xsl:otherwise>
              <xsl:value-of select="@type" />
            </xsl:otherwise>
          </xsl:choose>
                
        </xsl:attribute>
        
        <xsl:attribute name="x">
          <xsl:choose>
            <xsl:when test="string-length(@view_nbr_characters)>0 and (@type='text' or @type='textblock')">
              <xsl:text>(f,when,(loop,i,exists?,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>),(f,substring,(loop,i,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>),0,</xsl:text>
              <xsl:value-of select="@view_nbr_characters" />
              <xsl:text>),?)</xsl:text>
            </xsl:when>
            <xsl:when test="string-length(@number_format)>0">
              <xsl:text>(f,when,(loop,i,exists?,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>),(f,format,(loop,i,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>),</xsl:text>
              <xsl:value-of select="@number_format" />
              <xsl:text>),?)</xsl:text>
            </xsl:when>            
            <xsl:when test="@type='bool'"> 
              <xsl:text>(f,when,(loop,i,exists?,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>),(f,when,(loop,i,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>),Yes,No),?)</xsl:text>          
            </xsl:when>   

            <xsl:when test="@type='dir' or @type='file'"> 
              <xsl:text>(f,escape,dummy,(loop,i,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>),1)</xsl:text>        
            </xsl:when>                          
                       
                       
            <!--
            <xsl:otherwise>  
              <xsl:text>(f,when,(loop,i,exists?,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>),(loop,i,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>),?)</xsl:text>                     
            </xsl:otherwise>
             -->
            <xsl:otherwise>  
              <xsl:text>(loop,i,@</xsl:text>
              <xsl:value-of select="@id" />
              <xsl:text>)</xsl:text>                     
            </xsl:otherwise>             
          </xsl:choose>
        </xsl:attribute>
 
        <xsl:if test="@align='right'">
          <xsl:attribute name="align">
            <xsl:text>right</xsl:text>
          </xsl:attribute>          
        </xsl:if>  
        <xsl:if test="(@type='dir' or @type='file') and string-length(@view_nbr_characters)>0">
          <xsl:attribute name="len">
            <xsl:value-of select="@view_nbr_characters" />
          </xsl:attribute>          
        </xsl:if>  
        <xsl:if test="(@type='dir' or @type='file')">
          <xsl:attribute name="flag">
            <xsl:text>translate</xsl:text>
          </xsl:attribute>          
        </xsl:if>                     
      </ti>      
  </xsl:if>
</xsl:template>

<!-- ******************************************* -->
<xsl:template match="field" mode="header">
  <!-- loop <ti x="(f,html,bold,open)Name(f,html,bold,close)" width="100px" />  -->
  <xsl:if test="@view_flag=1">
     <ti>
        <xsl:attribute name="x">
          <xsl:choose>
            <xsl:when test="string-length(@view_label)>0">
              <xsl:value-of select="@view_label" />
            </xsl:when>
            <xsl:otherwise>
              <xsl:value-of select="@label" />
            </xsl:otherwise>
          </xsl:choose>
        </xsl:attribute>
        <xsl:if test="@align='right'">
          <xsl:attribute name="align">
            <xsl:text>right</xsl:text>
          </xsl:attribute>          
        </xsl:if>      
      </ti>      
  </xsl:if>
</xsl:template>

<xsl:template name="add_button" >
  <when>
  <xsl:attribute name="test">
    <xsl:text>(f,not,(f,contains,</xsl:text>
    <xsl:value-of select="s2/@prop_cities_offset" />
    <xsl:text>,node(entity:bo)(entity:bc)))</xsl:text>   
  </xsl:attribute>
  <xsl:if test="s1/@view_add_padding_top = '1'">
    <ti><ti/></ti>
  </xsl:if>
  <ti>
    <xsl:if test="s1/@view_add_location='bottom'">
      <xsl:attribute name="label">
        <xsl:text> </xsl:text>
      </xsl:attribute> 
    </xsl:if>
    
    <xsl:attribute name="type">
      <xsl:value-of select="s2/@ti_call" />
    </xsl:attribute>      
    <xsl:attribute name="explain">
      <xsl:value-of select="s2/@job_city_add" />
    </xsl:attribute>
    <xsl:attribute name="explain_alt">
      <xsl:value-of select="s1/@label_add" /><xsl:text> </xsl:text><xsl:value-of select="s1/@singular_label" /><xsl:value-of select="s2/@prop_cities_offset_label" />
    </xsl:attribute>      
    <xsl:attribute name="job">
      <xsl:value-of select="s2/@job_city_add" />
    </xsl:attribute>     
    <xsl:call-template name="introduction"/>

  </ti> 
  </when>
</xsl:template>

<xsl:template name="insert_view_trailer" >
  <xsl:if test="string-length(//s1/@view_trailer_span)>0">

    <ti x=" ">
      <xsl:attribute name="span">
        <xsl:value-of select="//s1/@view_trailer_span" />
      </xsl:attribute>        
    </ti>
    
  </xsl:if>
</xsl:template>

</xsl:stylesheet>

  
