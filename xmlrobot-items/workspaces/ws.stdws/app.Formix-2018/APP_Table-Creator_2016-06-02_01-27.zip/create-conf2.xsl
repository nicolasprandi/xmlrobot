<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright © 2015 Nicolas Prandstaetter. 
This file is part of an Ava-Application.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This file is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the Ava-Application.  If not, see &lt;http://www.gnu.org/licenses/&gt;. -->


<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:output method="xml" indent="yes"/>

<xsl:template match="/">
   <xsl:apply-templates/>
</xsl:template>

<xsl:template match="s1">
  <s2>

    <xsl:attribute name="prop_cities_sort_attribute">
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@plural_id" />
      <xsl:text>_sort_attribute)</xsl:text>
    </xsl:attribute>

    <xsl:attribute name="prop_cities_sort_number">
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@plural_id" />
      <xsl:text>_sort_number)</xsl:text>
    </xsl:attribute>
    
    <xsl:attribute name="prop_cities_sort_ignore_case">
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@plural_id" />
      <xsl:text>_sort_ignore_case)</xsl:text>
    </xsl:attribute>
    
    <xsl:attribute name="prop_cities_sort_desc">
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@plural_id" />
      <xsl:text>_sort_desc)</xsl:text>
    </xsl:attribute>        
    
    <xsl:attribute name="prop_cities_where">
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@plural_id" />
      <xsl:text>_where)</xsl:text>
    </xsl:attribute>    
        
    <xsl:attribute name="prop_key">
      <xsl:text>(prop,</xsl:text>
      <xsl:value-of select="@singular_id" />
      <xsl:text>_key)</xsl:text>
    </xsl:attribute>

    <xsl:attribute name="key">
      <xsl:value-of select="@singular_id" />
      <xsl:text>_key</xsl:text>
    </xsl:attribute>
    
    <xsl:attribute name="spirit">
      <xsl:value-of select="@plural_id" />
      <xsl:text>_spirit_tc</xsl:text>
    </xsl:attribute>    
          
    <xsl:attribute name="file_cities">
      <xsl:text>(file,</xsl:text><xsl:value-of select="@plural_id" /><xsl:text>)</xsl:text>
    </xsl:attribute>
    
    <xsl:attribute name="prop_cities_offset_label">
      <xsl:text>(prop,</xsl:text><xsl:value-of select="@plural_id" /><xsl:text>_offset_label)</xsl:text>
    </xsl:attribute>
    
    <xsl:attribute name="prop_cities_offset">
      <xsl:text>(prop,</xsl:text><xsl:value-of select="@plural_id" /><xsl:text>_offset)</xsl:text>
    </xsl:attribute>
    
    <xsl:attribute name="cities_offset_new_key">
      <xsl:value-of select="@plural_id" /><xsl:text>_offset_new_key</xsl:text>
    </xsl:attribute>
    
    <xsl:attribute name="job_city_details">
      <xsl:value-of select="@label_details" /><xsl:text> </xsl:text><xsl:value-of select="@singular_label" />
    </xsl:attribute>
    
    <xsl:attribute name="job_city_delete">
      <xsl:value-of select="@label_delete" /><xsl:text> </xsl:text><xsl:value-of select="@singular_label" />
    </xsl:attribute>
    
    <xsl:attribute name="job_city_edit">
      <xsl:value-of select="@label_edit" /><xsl:text> </xsl:text><xsl:value-of select="@singular_label" />
    </xsl:attribute> 
    
    <xsl:attribute name="job_city_editor">
      <xsl:value-of select="@singular_label" /><xsl:text> Editor</xsl:text>
    </xsl:attribute>     
    
    <xsl:attribute name="job_city_view">
      <xsl:value-of select="@label_view" /><xsl:text> </xsl:text><xsl:value-of select="@plural_label" />
    </xsl:attribute>  
    
    <xsl:attribute name="job_city_add">
      <xsl:value-of select="@label_add" /><xsl:text> </xsl:text><xsl:value-of select="@singular_label" />
    </xsl:attribute>  
    
    <xsl:attribute name="job_city_tomemory">
      <xsl:text>To Memory </xsl:text><xsl:value-of select="@singular_label" />
    </xsl:attribute>  
    
    <xsl:attribute name="job_city_tofile">
      <xsl:text>To File </xsl:text><xsl:value-of select="@singular_label" />
    </xsl:attribute>  
    
    <xsl:attribute name="job_city_validate">
      <xsl:text>Validate </xsl:text><xsl:value-of select="@singular_label" />
    </xsl:attribute>
    <xsl:attribute name="city_input_valid">
      <xsl:value-of select="@singular_id" /><xsl:text>_input_valid</xsl:text>
    </xsl:attribute>
    <xsl:attribute name="city_input_loop">
      <xsl:value-of select="@singular_id" /><xsl:text>_loop</xsl:text>
    </xsl:attribute>        
    <xsl:attribute name="prop_city_input_valid">
      <xsl:text>(prop,</xsl:text><xsl:value-of select="@singular_id" /><xsl:text>_input_valid)</xsl:text>
    </xsl:attribute>                   

    <xsl:attribute name="filename_prolog">
      <xsl:choose>
        <xsl:when test="string-length(@alternative_prolog)>0">
          <xsl:value-of select="@alternative_prolog" />
        </xsl:when>
        <xsl:otherwise>
          <xsl:value-of select="@plural_id" />
          <xsl:text>-prolog.lsx</xsl:text>        
        </xsl:otherwise>
      </xsl:choose>
    </xsl:attribute>     
    
    <xsl:attribute name="see_keys">
      <xsl:choose>
        <xsl:when test="string-length(@see_keys)>0">
          <xsl:value-of select="@see_keys" />
        </xsl:when>
        <xsl:otherwise>
          <xsl:text>1</xsl:text>        
        </xsl:otherwise>
      </xsl:choose>
    </xsl:attribute>            
    
    <xsl:attribute name="loop_i_row">
      <xsl:text>(loop,i,@</xsl:text><xsl:value-of select="@id_attribute_name" /><xsl:text>)</xsl:text>
    </xsl:attribute>  
    
    <xsl:attribute name="city_dt_upd">
      <xsl:value-of select="@singular_id" /><xsl:text>_dt_upd</xsl:text>
    </xsl:attribute> 
    
    <xsl:attribute name="city_dt_add">
      <xsl:value-of select="@singular_id" /><xsl:text>_dt_add</xsl:text>
    </xsl:attribute>            
    
    <xsl:attribute name="prop_return_job">
      <xsl:text>(prop,</xsl:text><xsl:value-of select="@plural_id" /><xsl:text>_return_job)</xsl:text>
    </xsl:attribute>   
    
    <xsl:attribute name="return_job">
      <xsl:value-of select="@plural_id" /><xsl:text>_return_job</xsl:text>
    </xsl:attribute>    
    
    <xsl:attribute name="ti_call">
      <xsl:choose>
        <xsl:when test="@usage='service'">
          <xsl:text>call_service</xsl:text>
        </xsl:when>
        <xsl:otherwise>
          <xsl:text>call_job</xsl:text>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:attribute> 
    
    <xsl:attribute name="usage">
      <xsl:choose>
        <xsl:when test="@usage='service'">
          <xsl:text>service</xsl:text>
        </xsl:when>
        <xsl:otherwise>
          <xsl:text>app</xsl:text>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:attribute>   
    
    <xsl:attribute name="datafile">
      <xsl:choose>
        <xsl:when test="@usage='service'">
          <xsl:text>(dir,services)</xsl:text>
        </xsl:when>
        <xsl:otherwise>
          <xsl:text>(dir,pro)</xsl:text>
        </xsl:otherwise>
      </xsl:choose>
      <xsl:value-of select="@plural_id" />
      <xsl:text>.xml</xsl:text>
    </xsl:attribute>                               
                 
  </s2>
</xsl:template>

</xsl:stylesheet>

  
