<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright © 2015 Nicolas Prandstaetter. 
This file is part of an Ava-Application.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This file is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the Ava-Application.  If not, see &lt;http://www.gnu.org/licenses/&gt;. -->


<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:output method="xml" indent="yes"/>
<xsl:include href="include-introduction.xsl" />
<xsl:include href="include-hooks2.xsl" />

<xsl:template match="/">
   <xsl:apply-templates/>
</xsl:template>

<xsl:template match="conf">

<!-- <job id="City Details" role="hidden">  -->
<job role="hidden">
  <xsl:attribute name="id"><xsl:value-of select="s2/@job_city_details" /></xsl:attribute>    
  
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">details</xsl:with-param>
          <xsl:with-param name="hook">begin</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>
    
  <need><xsl:value-of select="s2/@prop_key" /></need>
  <!-- <call job="City to_memory"/>  -->
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">details</xsl:with-param>
          <xsl:with-param name="hook">0</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>  
  <xsl:choose>
    <xsl:when test="s2/@usage='app'">
      <call_job>
        <xsl:attribute name="job"><xsl:value-of select="s2/@job_city_tomemory" /></xsl:attribute>   
      </call_job>
    </xsl:when>
    <xsl:when test="s2/@usage='service'">
      <call_service>
        <xsl:attribute name="job"><xsl:value-of select="s2/@job_city_tomemory" /></xsl:attribute>   
      </call_service>
    </xsl:when>  
  </xsl:choose>  

        <xsl:call-template name="hook2">
          <xsl:with-param name="page">details</xsl:with-param>
          <xsl:with-param name="hook">1</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>
    
  <!-- <ti label="(prop,city_name)(prop,cities_offset_label) ((prop,rec_id))">  -->
  
  <xsl:choose>
    <xsl:when test="s1/@details_header='1'">
      <ti_hr/>
      <ti>
        <xsl:attribute name="label">
          <xsl:text>[ </xsl:text>
          <xsl:value-of select="fields/@name_expression" />
          <xsl:text> ]</xsl:text>
          <!--
          <xsl:text>[BIG:ON]</xsl:text>
          <xsl:value-of select="fields/@name_expression" />
          <xsl:text>[BIG:OFF]</xsl:text>
                  
          <xsl:text> </xsl:text>
          <xsl:value-of select="s1/@singular_label" />
           
          <xsl:text></xsl:text>
          <xsl:value-of select="s1/@singular_label" />
          <xsl:text> '</xsl:text>
          <xsl:text>[BIG:ON]</xsl:text>
          <xsl:value-of select="fields/@name_expression" />
          <xsl:text>[BIG:OFF]</xsl:text>
          <xsl:text>'</xsl:text>      
          -->      
        </xsl:attribute>
        <xsl:attribute name="key">
          <xsl:text>#</xsl:text>
          <xsl:value-of select="s2/@prop_key" />
        </xsl:attribute>
       </ti> 
    </xsl:when>   
    <xsl:otherwise>
      <ti label=" ">
        <xsl:attribute name="key">
          <xsl:text>#</xsl:text>
          <xsl:value-of select="s2/@prop_key" />
        </xsl:attribute>  
      </ti>
    </xsl:otherwise>   
  </xsl:choose>
  
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">details</xsl:with-param>
          <xsl:with-param name="hook">5</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>    
  
 
    
  <ti padding_top="0px">
    <xsl:attribute name="laxxbel">
      <xsl:value-of select="fields/@name_expression" />
      <xsl:value-of select="s2/@prop_cities_offset_label" />
    </xsl:attribute>
         
    <xsl:apply-templates select="fields/field" mode="detail">
      <xsl:sort select="@position"/>
    </xsl:apply-templates>
    
  </ti>  
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">details</xsl:with-param>
          <xsl:with-param name="hook">8</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>  
  <xsl:if test="s1/@details_delete=1 or s1/@details_edit=1 or count(//conf/actions/action[@details='1'])>0">
        <xsl:call-template name="hook2">
          <xsl:with-param name="page">details</xsl:with-param>
          <xsl:with-param name="hook">9</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>
    <ti_hr/>
    <ti padding_top="6px">
    
      <xsl:choose>
        <xsl:when test="string-length(s1/@actions_label)>0">
          <xsl:attribute name="label">
            <xsl:value-of select="s1/@actions_label" />
          </xsl:attribute>           
        </xsl:when>
        <xsl:otherwise>
          <xsl:attribute name="label">
            <xsl:text>Actions</xsl:text>
          </xsl:attribute>          
        </xsl:otherwise>
      </xsl:choose>
    
      <xsl:if test="s1/@details_edit=1">
        <ti>
          <xsl:attribute name="type">
            <xsl:value-of select="s2/@ti_call" />
          </xsl:attribute>          
          <xsl:attribute name="explain">
            <xsl:value-of select="s1/@label_edit" /> 
          </xsl:attribute> 
          <xsl:attribute name="job">
            <xsl:value-of select="s2/@job_city_edit" /> 
          </xsl:attribute>                
          <prop>
            <xsl:attribute name="id">
              <xsl:value-of select="s2/@key" /> 
            </xsl:attribute>           
            <xsl:value-of select="s2/@prop_key" />
          </prop>
          <xsl:call-template name="introduction"/>
        </ti>  
      </xsl:if>

      <xsl:if test="s1/@details_delete=1">
        <ti>
          <xsl:attribute name="type">
            <xsl:value-of select="s2/@ti_call" />
          </xsl:attribute>          
          <xsl:attribute name="explain">
            <xsl:value-of select="s1/@label_delete" /> 
          </xsl:attribute> 
          <xsl:attribute name="job">
            <xsl:value-of select="s2/@job_city_delete" /> 
          </xsl:attribute>                
          <prop>
            <xsl:attribute name="id">
              <xsl:value-of select="s2/@key" /> 
            </xsl:attribute>           
            <xsl:value-of select="s2/@prop_key" />
          </prop>
          <xsl:call-template name="introduction"/>
        </ti>  
      </xsl:if>
    
      <xsl:apply-templates select="//conf/actions/action[@details='1']" mode="ti_call"> 
        <xsl:with-param name="page"><xsl:text>details</xsl:text></xsl:with-param>          
        <xsl:sort select="@sort"/>

      </xsl:apply-templates>       
                
    </ti>    
         <xsl:call-template name="hook2">
          <xsl:with-param name="page">details</xsl:with-param>
          <xsl:with-param name="hook">12</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template> 
  </xsl:if>
          <xsl:call-template name="hook2">
          <xsl:with-param name="page">details</xsl:with-param>
          <xsl:with-param name="hook">13</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template>
 

         <xsl:call-template name="hook2">
          <xsl:with-param name="page">details</xsl:with-param>
          <xsl:with-param name="hook">end</xsl:with-param>
          <xsl:with-param name="station">0</xsl:with-param>
        </xsl:call-template> 

  
</job>
</xsl:template>

<!-- ******************************************* -->
<xsl:template match="field" mode="detail">
  <!--  <ti label="State:">(prop,city_state)</ti>
        <ti label="Population:">(f,format,(prop,city_population),#(entity:co)###)</ti>  -->
      
  <ti>
    <xsl:attribute name="label">      
      <xsl:value-of select="@label" />
      <xsl:text>:</xsl:text>   
    </xsl:attribute>
    
    <xsl:attribute name="type">  
      <xsl:choose>    
        <xsl:when test="@type='dir'"> 
          <xsl:text>dir</xsl:text>     
        </xsl:when>  
        <xsl:when test="@type='file'"> 
          <xsl:text>file</xsl:text>     
        </xsl:when>        
        <xsl:otherwise>
          <xsl:text>text</xsl:text>
        </xsl:otherwise>
      </xsl:choose> 
    </xsl:attribute>
    
    <xsl:choose>    
      <xsl:when test="string-length(@ti_test)>0">
        <xsl:attribute name="test"> 
          <xsl:value-of select="@ti_test" />     
        </xsl:attribute>   
      </xsl:when>  
      <xsl:otherwise>
        <xsl:attribute name="test"> 
          <xsl:text>(f,has,</xsl:text>
          <xsl:choose>
            <xsl:when test="@type='dir'">
              <xsl:text>dir</xsl:text>
            </xsl:when>
            <xsl:when test="@type='file'">
              <xsl:text>file</xsl:text>
            </xsl:when>
            <xsl:otherwise>
              <xsl:text>prop</xsl:text>
            </xsl:otherwise>
          </xsl:choose> 
          <xsl:text>,</xsl:text>                       
          <xsl:value-of select="//s1/@singular_id" />
          <xsl:text>_</xsl:text>
          <xsl:value-of select="@id" />
          <xsl:text>)</xsl:text>   
        </xsl:attribute>       
      </xsl:otherwise>
    </xsl:choose>         
    <!-- 
    <xsl:if test="@name_flag='1'">
      <xsl:text>(f,html,bold,open)</xsl:text>
    </xsl:if>  
    -->
    
    <xsl:choose>
      <xsl:when test="string-length(@number_format)>0">
        <xsl:text>(f,format,(prop,</xsl:text>
        <xsl:value-of select="//s1/@singular_id" />
        <xsl:text>_</xsl:text>
        <xsl:value-of select="@id" />
        <xsl:text>),</xsl:text>
        <xsl:value-of select="@number_format" /> 
        <xsl:text>)</xsl:text>
      </xsl:when>  
      <xsl:when test="@type='bool'"> 
        <xsl:text>(f,when,</xsl:text>
        <xsl:text>(prop,</xsl:text>
        <xsl:value-of select="//s1/@singular_id" />
        <xsl:text>_</xsl:text>
        <xsl:value-of select="@id" />
        <xsl:text>)</xsl:text>  
        <xsl:text>,Yes,No)</xsl:text>      
      </xsl:when>           
      <xsl:otherwise>  
        <xsl:text>(</xsl:text>
        <xsl:value-of select="@vartype" />
        <xsl:text>,</xsl:text>
        <xsl:value-of select="//s1/@singular_id" />
        <xsl:text>_</xsl:text>
        <xsl:value-of select="@id" />
        <xsl:text>)</xsl:text>                     
      </xsl:otherwise>
    </xsl:choose> 
    <!-- 
    <xsl:if test="@name_flag='1'">
      <xsl:text>(f,html,bold,open)</xsl:text>
    </xsl:if>     
    -->      
  </ti> 

</xsl:template>


</xsl:stylesheet>

  
